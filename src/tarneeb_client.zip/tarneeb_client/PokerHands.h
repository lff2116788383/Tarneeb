#pragma once
#include <QVector>
#include "Card.h"
class PokerHands
{
public:
	PokerHands();
	~PokerHands();
	void SetCards(Card* card);
	QVector<Card*> GetCards();
	void SortCard(unsigned short color);

	Card* GetBestCard();
	Card* GetWorstCard();
	Card* GetBestCardByLast(Card* lastCard);//

	void DelCard(Card* card);
private:
	QVector<Card*>mCards;
	//unsigned short mainColor;
};
