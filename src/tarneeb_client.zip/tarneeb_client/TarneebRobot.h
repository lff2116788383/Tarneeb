#pragma once
#include "GameUser.h"
class TarneebRobot:public GameUser
{
public:
	TarneebRobot();
	~TarneebRobot();

private:

};

TarneebRobot::TarneebRobot()
{
}

TarneebRobot::~TarneebRobot()
{
}