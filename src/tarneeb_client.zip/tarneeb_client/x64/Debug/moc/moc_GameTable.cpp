/****************************************************************************
** Meta object code from reading C++ file 'GameTable.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../GameTable.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GameTable.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GameTable_t {
    QByteArrayData data[11];
    char stringdata0[153];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameTable_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameTable_t qt_meta_stringdata_GameTable = {
    {
QT_MOC_LITERAL(0, 0, 9), // "GameTable"
QT_MOC_LITERAL(1, 10, 19), // "OnShuffleBtnClicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 16), // "OnCallBtnClicked"
QT_MOC_LITERAL(4, 48, 19), // "OnNotCallBtnClicked"
QT_MOC_LITERAL(5, 68, 20), // "OnPlayCardBtnClicked"
QT_MOC_LITERAL(6, 89, 15), // "OnPlayCardRobot"
QT_MOC_LITERAL(7, 105, 6), // "SeatID"
QT_MOC_LITERAL(8, 112, 10), // "GetWinSeat"
QT_MOC_LITERAL(9, 123, 16), // "QMap<Card*,int>&"
QT_MOC_LITERAL(10, 140, 12) // "roundCardMap"

    },
    "GameTable\0OnShuffleBtnClicked\0\0"
    "OnCallBtnClicked\0OnNotCallBtnClicked\0"
    "OnPlayCardBtnClicked\0OnPlayCardRobot\0"
    "SeatID\0GetWinSeat\0QMap<Card*,int>&\0"
    "roundCardMap"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameTable[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   44,    2, 0x09 /* Protected */,
       3,    0,   45,    2, 0x09 /* Protected */,
       4,    0,   46,    2, 0x09 /* Protected */,
       5,    0,   47,    2, 0x09 /* Protected */,
       6,    1,   48,    2, 0x09 /* Protected */,
       8,    1,   51,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Int, 0x80000000 | 9,   10,

       0        // eod
};

void GameTable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GameTable *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->OnShuffleBtnClicked(); break;
        case 1: _t->OnCallBtnClicked(); break;
        case 2: _t->OnNotCallBtnClicked(); break;
        case 3: _t->OnPlayCardBtnClicked(); break;
        case 4: _t->OnPlayCardRobot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: { int _r = _t->GetWinSeat((*reinterpret_cast< QMap<Card*,int>(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GameTable::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_GameTable.data,
    qt_meta_data_GameTable,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameTable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameTable::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameTable.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameTable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
