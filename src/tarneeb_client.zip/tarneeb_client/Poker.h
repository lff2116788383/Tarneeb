#pragma once
#include "Card.h"
#include <QVector>
//52���˿�	��ȥ��С��
class Poker
{
public:
	Poker();
	~Poker();
	void Shuffle();
	QVector<Card*> GetCards();
private:
	QVector<Card*>mCards;
};

