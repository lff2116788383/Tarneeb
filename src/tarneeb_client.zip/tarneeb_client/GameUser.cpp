#include "GameUser.h"
GameUser::GameUser(QObject* parent)
	: QObject(parent)
{
	m_pokerHand = new PokerHands;
	mCall = 0;
	mScore = 0;
	isCall = true;//Ĭ�϶�����з�
}

GameUser::~GameUser()
{
}

void GameUser::AddScore(int score)
{
	mScore += score;
}

void GameUser::SetCall(int call)
{
	mCall = call;
}

int GameUser::GetCall()
{
	return mCall;
}

int GameUser::GetScore()
{
	return mScore;
}

void GameUser::SetPokerHands(Card* card)
{
	m_pokerHand->SetCards(card);
}

PokerHands* GameUser::GetPokerHands()
{
	return m_pokerHand;
}

bool GameUser::IsCall()
{
	return isCall;
}

void GameUser::SetIsCall(bool flag)
{
	isCall = flag;
}

void GameUser::SignPlayCard(int SeatID)
{
	emit NotifySeatChanged(SeatID);
}


