#include "Card.h"
MapItem::MapItem() :
    QObject(),
    QGraphicsPixmapItem(),
    mBoundingRect(QRect()),
    mShape(QPainterPath()),
    mImageSelected(0),
    mImageEvent(0),
    mMapItemName(""),
    mObstacle(false)
{
    //this->setAcceptedMouseButtons(Qt::LeftButton);
    //setFlag(QGraphicsItem::ItemIsSelectable);//���������䣬����item�޷���ȡ������¼�
}

MapItem::~MapItem()
{

}

QPixmap MapItem::getImage()
{
    return mImage.copy(static_cast<int>(mImageSelected * boundingRect().width()), 0, static_cast<int>(boundingRect().width()), static_cast<int>(boundingRect().height()));
}


QString MapItem::invocName()
{
    return mMapItemName;
}

QRectF MapItem::boundingRect() const
{
    return mBoundingRect;
}

QPainterPath MapItem::shape() const
{
    return mShape;
}

void MapItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    painter->setRenderHint(QPainter::Antialiasing);
    painter->drawPixmap(0, 0, mImage, static_cast<int>(mImageSelected * boundingRect().width()), static_cast<int>(mImageEvent * boundingRect().height()), static_cast<int>(boundingRect().width()), static_cast<int>(boundingRect().height()));
    Q_UNUSED(widget)
        Q_UNUSED(option)
}



MapItemMovable::MapItemMovable() :
    MapItem(),
    mHover(false),
    mMove(true),
    mReadyToDelete(false)
{
    setFlag(QGraphicsItem::ItemIsMovable, true);
    setAcceptedMouseButtons(Qt::MouseButton::LeftButton);
    setAcceptHoverEvents(true);

    t_delay_sound = new QTimer(this);
    t_delay_sound->setSingleShot(true);
}

MapItemMovable::~MapItemMovable()
{

}

void MapItemMovable::setShape()
{
    QGraphicsPixmapItem* tmp = new QGraphicsPixmapItem(this);
    tmp->setPixmap(mImage.copy(static_cast<int>(mImageSelected * boundingRect().width()), 0, static_cast<int>(boundingRect().width()), static_cast<int>(boundingRect().height())));
    mBorders = tmp->shape();
    delete tmp;
}

void MapItemMovable::setInitialPosition(QPointF p)
{
    mInitialPosition = p;
}

void MapItemMovable::setReadyToDelete()
{
    mReadyToDelete = true;
}

bool MapItemMovable::isObstacle()
{
    return mObstacle;
}

void MapItemMovable::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsItem::mousePressEvent(event);
}

void MapItemMovable::mouseReleaseEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsItem::mouseReleaseEvent(event);
    if (mReadyToDelete)
        emit sig_deleteItem(this);
}

void MapItemMovable::mouseMoveEvent(QGraphicsSceneMouseEvent* event)
{
    qreal dx = abs(pos().x() - mInitialPosition.x()),
        dy = abs(pos().y() - mInitialPosition.y());

    if (qSqrt(qPow(dx, 2) + qPow(dy, 2)) > 90 && mMove) {
        setFlag(QGraphicsItem::ItemIsMovable, false);
        setAcceptHoverEvents(false);
        mHover = false;
        mMove = false;
        update();
        emit sig_itemPositionFixed(this);
    }
    else {
        if (!t_delay_sound->isActive()) {
            t_delay_sound->start(1000);
            emit sig_itemMoved(this);
        }
    }

    QGraphicsItem::mouseMoveEvent(event);
}

void MapItemMovable::hoverEnterEvent(QGraphicsSceneHoverEvent* event)
{
    if (event->HoverEnter == QGraphicsSceneHoverEvent::HoverEnter)
    {
        mHover = true;
        update();
        event->accept();
    }
}

void MapItemMovable::hoverLeaveEvent(QGraphicsSceneHoverEvent* event)
{
    if (event->HoverLeave == QGraphicsSceneHoverEvent::HoverLeave)
    {
        mHover = false;
        update();
        event->accept();
    }
}

void MapItemMovable::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    painter->setRenderHint(QPainter::Antialiasing);
    painter->drawPixmap(0, 0, mImage, static_cast<int>(mImageSelected * boundingRect().width()), 0, static_cast<int>(boundingRect().width()), static_cast<int>(boundingRect().height()));

    if (mHover) {
        painter->setPen(QPen(QBrush(BORDERS_COLOR), 2));
        painter->drawPath(mBorders);
    }

    Q_UNUSED(widget)
        Q_UNUSED(option)
}



Card::Card(unsigned int point, unsigned int color):
    mPoint(point),
    mColor(color),
    isSelected(false),
    isFlop(false),
    MapItem()
{
    /*setFlags(QGraphicsItem::ItemIsMovable | QGraphicsItem::ItemIsSelectable | QGraphicsItem::ItemIsFocusable | QGraphicsItem::ItemSendsGeometryChanges | QGraphicsItem::ItemUsesExtendedStyleOption);
    setAcceptHoverEvents(true);*/
    //setFlag(QGraphicsItem::ItemIsMovable, true);
    setAcceptedMouseButtons(Qt::MouseButton::LeftButton);
    setAcceptHoverEvents(true);

    initMapItem();
}

void Card::Flop() 
{
   
    isFlop = true;

    //���ݵ�����ȡ�˿�ͼƬ
    QPixmap cardsPic(":/tarneeb_client/res/card.png");
    if (mPoint == 2)
        mImage = cardsPic.copy((14 - mPoint) * m_cardSize.width(), (mColor - 1) * m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    else
    {
        mImage = cardsPic.copy((mPoint - 3) * m_cardSize.width(), (mColor - 1) * m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    }
}

bool Card::Selected()
{
    return isSelected;
}

void Card::SetSelected(bool flag)
{
    isSelected = flag;
}

void Card::initMapItem()
{
    QString buff = "";
    mMapItemName = "�˿�";
    mImageSelected = 0;
    //mImage = QPixmap(":/tarneeb_client/res/card.png");
    m_cardSize = QSize(80,105);

    QPixmap cardsPic(":/tarneeb_client/res/card.png");

    //���ݵ�����ȡ�˿�ͼƬ
   /* if(mPoint==2)
    mImage=cardsPic.copy((14-mPoint)* m_cardSize.width(),(mColor-1)* m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    else
    {
        mImage = cardsPic.copy((mPoint-3) * m_cardSize.width(), (mColor - 1) * m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    }*/

    //�з�ǰ����ʾ��ɫ���Ƶ�
    if(mPoint==0||mColor==0||!isFlop)mImage = cardsPic.copy(2 * m_cardSize.width(),4 * m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    setZValue(0);
    
    mBoundingRect = QRect(0, 0, mImage.width(), mImage.height());
    mShape.addRect(QRectF(0, 0, boundingRect().width(), boundingRect().height()));
    //setRotation(rand() % (30) - 15);
}

void Card::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
   /* int i = ev->x();
    int j = ev->y();*/
    //�ж���갴��
    if (event->button() == Qt::LeftButton)
    {
       
        if (isSelected)
        {
            isSelected = false;
            this->setY(this->y() + 10);
        }
        else
        {
            isSelected = true;
            this->setY(this->y() - 10);
        }

        
        //qDebug() << "left";
        //qDebug() << "Item: (" << event->scenePos().x() << ", " << event->scenePos().y() << ')';
    }

    //�����ݵ��ص���item
    //QGraphicsItem::mousePressEvent(event);
    

    
}

bool Card::isObstacle()
{
    return mObstacle;
}

Card::~Card()
{

}

bool CompLess(const Card* lhs, const Card* rhs)
{
    if (lhs->mPoint != rhs->mPoint)
        return lhs->mPoint < rhs->mPoint;
    else
    {
        return lhs->mColor < rhs->mColor;
    }
}


#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")// ��ָ���֧��VS����
#endif
#include <QDebug>
//��ӡ����
void PrintfCards(QVector<Card*> totalcards)
{
    QString ret{};
    for (int i = totalcards.size()-1; i >=0; i--)
    {
        
        QString str{};
        switch (totalcards[i]->mColor)
        {
        case Diamond:
            str = "����";
            break;
        case Club:
            str = "÷��";
            break;
        case Heart:
            str = "����";
            break;
        case Spade:
            str = "����";
            break;
        default:
            break;
        }

        switch (totalcards[i]->mPoint)
        {
        case Card_J:
            str += "J";
            break;
        case Card_Q:
            str += "Q";
            break;
        case Card_K:
            str += "K";
            break;
        case Card_A:
            str += "A";
            break;
        default:
            str += QString::number(totalcards[i]->mPoint);

            break;
        }
      
       
        ret += str;
       
        if (i % 13 == 0)//0-12 13-25 26-38 39-51
        {
            qDebug() << ret;
            ret.clear();
        }
           
       
    }
   
}

void PrintfCards(std::vector<Card*> totalcards)
{
    QString ret{};
    for (int i = totalcards.size() - 1; i >= 0; i--)
    {

        QString str{};
        switch (totalcards[i]->mColor)
        {
        case Diamond:
            str = "����";
            break;
        case Club:
            str = "÷��";
            break;
        case Heart:
            str = "����";
            break;
        case Spade:
            str = "����";
            break;
        default:
            break;
        }

        switch (totalcards[i]->mPoint)
        {
        case Card_J:
            str += "J";
            break;
        case Card_Q:
            str += "Q";
            break;
        case Card_K:
            str += "K";
            break;
        case Card_A:
            str += "A";
            break;
        default:
            str += QString::number(totalcards[i]->mPoint);

            break;
        }


        ret += str;

        if (i % 13 == 0)
        {
            qDebug() << ret;
            ret.clear();
        }


    }

}