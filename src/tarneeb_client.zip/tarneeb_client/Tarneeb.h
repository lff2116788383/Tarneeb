#pragma once

#include <QWidget>
#include "ui_Tarneeb.h"
#include <QGraphicsView>
#include <QGraphicsItem>
#include "GameTable.h"
class Tarneeb : public QWidget
{
	Q_OBJECT

public:
	Tarneeb(QWidget *parent = Q_NULLPTR);
	~Tarneeb();

	void paintEvent(QPaintEvent*);
private:
	Ui::Tarneeb ui;
	QGraphicsView* pView;
	GameTable* table;
};
