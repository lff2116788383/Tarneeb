/********************************************************************************
** Form generated from reading UI file 'TarneebbMlePE.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef TARNEEBBMLEPE_H
#define TARNEEBBMLEPE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Tarneeb
{
public:

    void setupUi(QWidget *Tarneeb)
    {
        if (Tarneeb->objectName().isEmpty())
            Tarneeb->setObjectName(QString::fromUtf8("Tarneeb"));
        Tarneeb->resize(400, 300);

        retranslateUi(Tarneeb);

        QMetaObject::connectSlotsByName(Tarneeb);
    } // setupUi

    void retranslateUi(QWidget *Tarneeb)
    {
        Tarneeb->setWindowTitle(QCoreApplication::translate("Tarneeb", "Tarneeb", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Tarneeb: public Ui_Tarneeb {};
} // namespace Ui

QT_END_NAMESPACE

#endif // TARNEEBBMLEPE_H
