#include "GameUser.h"
GameUser::GameUser()
{
	m_pokerHand = new PokerHands;
}

GameUser::~GameUser()
{
}

void GameUser::SetPokerHands(Card* card)
{
	m_pokerHand->SetCards(card);
}

PokerHands* GameUser::GetPokerHands()
{
	return m_pokerHand;
}
