#pragma once
#include "PokerHands.h"
class GameUser
{
public:
	GameUser();
	~GameUser();

	void SetPokerHands(Card* card );
	PokerHands* GetPokerHands();
	
private:
	PokerHands* m_pokerHand;
};
