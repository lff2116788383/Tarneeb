#pragma once
#include <QVector>
#include "Cards.h"
class PokerHands
{
public:
	PokerHands();
	~PokerHands();
	void SetCards(Card* card);
	QVector<Card*> GetCards();
	void SortCard(QVector<Card*> handcards, unsigned short color);
private:
	QVector<Card*>mCards;
};
