#include "GameTable.h"
GameTable::GameTable(QGraphicsView* view):
	mView(view)
{
	mScene = new QGraphicsScene(this);
	//���ó����ı߽緶Χ
	mScene->setSceneRect(QRect(0, 0, mView->width() , mView->height()));
	//���ó����ı�����ˢ
	//mScene->setBackgroundBrush(QPixmap(":/tarneeb_client/res/table.png"));

	// ����һ�� item
	QGraphicsSimpleTextItem* pItem = new QGraphicsSimpleTextItem();
	pItem->setText(QString::fromLocal8Bit("���֣�"));

	// ����
	QFont font = pItem->font();
	font.setPixelSize(20);  // ���ش�С
	//font.setItalic(true);  // б��
	//font.setUnderline(true);  // �»���
	pItem->setFont(font);
	pItem->setBrush(QBrush(QColor(0, 0, 0)));
	mScene->addItem(pItem);


	poker = new Poker;
	auto cards=poker->GetCards();
	Card* c0 = new Card(0, 0);
	Card* c1 = new Card(2,1);
	auto c2 = cards[25];
	c1->setPos(100,200);
	c2->setPos(100,100);
	//poker = new Poker;
	//Card* c2=poker->GetCards()[1];
	mScene->addItem(c0);
	mScene->addItem(c1);
	mScene->addItem(c2);

	

}

GameTable::~GameTable()
{
}



QGraphicsScene* GameTable::GetScene()
{
	return mScene;
}

void GameTable::Shuffle()
{
}
