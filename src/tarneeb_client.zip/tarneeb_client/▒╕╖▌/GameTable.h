#pragma once
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include "Card.h"
#include "Poker.h"
#include "GameUser.h"
class GameTable : public QObject
{
	Q_OBJECT
public:
	GameTable(QGraphicsView* view);
	~GameTable();

	QGraphicsScene* GetScene();
protected slots:
	void Shuffle();
private:
	QGraphicsView* mView;
	QGraphicsScene* mScene;
	GameUser* user[4];
	Poker* poker;
	
};
