#pragma once
#include <QDialog>
#include <QWidget>
#include "ui_MainFrame.h"
#include "GamePanel.h"
class MainFrame : public QDialog
{
	Q_OBJECT

public:
	MainFrame(QWidget* parent = 0, Qt::WindowFlags flags = 0);
	~MainFrame();

	void resizeEvent(QResizeEvent* event);

private:
	Ui::MainFrame ui;
	GamePanel* m_gamePanel;
};
