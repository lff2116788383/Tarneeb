#include "Cards.h"

Card::Card()
{
}

void Card::SetPos(int posX, int PosY)
{
	x = posX;
	y = PosY;
}
