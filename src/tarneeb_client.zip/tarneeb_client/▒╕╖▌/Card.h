#pragma once
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPainter>
class MapItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    MapItem();
    ~MapItem();
signals:
    void sig_playSound(int);
public:
    QPixmap getImage();
    QString invocName();
    QPainterPath shape() const;
    QRectF boundingRect()const;
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget);
public:
    virtual bool isObstacle() = 0;
protected:
    QRect mBoundingRect;
    QPainterPath mShape;
    QPixmap mImage;
    int mImageSelected;
    int mImageEvent;
    QString mMapItemName;
    bool mObstacle;
};

class MapItemMovable : public MapItem
{
    Q_OBJECT
public:
    MapItemMovable();
    ~MapItemMovable();
signals:
    void sig_itemMoved(MapItem*);
    void sig_itemPositionFixed(MapItem*);
    void sig_deleteItem(MapItemMovable*);
public:
    void setInitialPosition(QPointF);
    void setReadyToDelete();

    bool isObstacle();
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget);
protected:
    void setShape();

    void mousePressEvent(QGraphicsSceneMouseEvent*);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent*);
    void mouseMoveEvent(QGraphicsSceneMouseEvent*);
    void hoverEnterEvent(QGraphicsSceneHoverEvent*);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent*);
private:
    QPainterPath mBorders;
    bool mHover;
    QPointF mInitialPosition;
    QTimer* t_delay_sound;
    bool mMove;
    bool mReadyToDelete;
};

enum Point
{
    Card_Begin=1,
    Card_2,
    Card_3,
    Card_4,
    Card_5,
    Card_6,
    Card_7,
    Card_8,
    Card_9,
    Card_10,
    Card_J,
    Card_Q,
    Card_K,
    Card_A,
   

    Card_SJ,
    Card_BJ,

    Card_End
};

const int PointCount = 15;

enum Suit
{
    Suit_Begin,

    Diamond,	// ����
    Club,		// ÷��
    Heart,		// ����
    Spade,		// ���� 

    Suit_End
};
class Card : public MapItem
{
public:
  
    Card(unsigned int point, unsigned int color);
    Card& operator= (const Card& a) {
        //printf("��ֵ����\n");
        this->mPoint = a.mPoint;
        this->mColor = a.mColor;
        initMapItem();
    }
    ~Card();
public:
    bool isObstacle();
private:
    void initMapItem();
public:
    unsigned int mPoint;
    unsigned int mColor;
    QSize m_cardSize;
};
