//#include "tarneeb_client.h"
#include <QtWidgets/QApplication>
//#include "MainFrame.h"
#include "Tarneeb.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   /* tarneeb_client w;
    w.show();*/

   

   /* MainFrame w;
    w.setWindowFlags(Qt::WindowMinimizeButtonHint | Qt::WindowCloseButtonHint);
    w.show();*/
    Tarneeb t;
    t.show();
    return a.exec();
}
//52��Card   