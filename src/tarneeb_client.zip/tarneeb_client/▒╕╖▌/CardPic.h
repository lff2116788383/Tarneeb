﻿#ifndef CARDPIC_H
#define CARDPIC_H

#include <QFrame>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QPixmap>
#include "Cards.h"
#include "GameUser.h"


class CardPic : public QFrame
{
	Q_OBJECT

public:
	CardPic(QWidget *parent);
	~CardPic();

	void SetPic(const QPixmap& pic, const QPixmap& back);
	QPixmap GetPic();

	void SetOwner(GameUser* owner);
	GameUser* GetOwner();

	void SetCard(Card card);
	Card GetCard();

	void SetFrontSide(bool frontSide);
	bool IsFrontSide();

	void SetSelected(bool selected);
	bool IsSelected();

	
signals:
	void NotifySelected(Qt::MouseButton);

protected:
	virtual void paintEvent(QPaintEvent* event);
	virtual void mousePressEvent(QMouseEvent* event);//重写鼠标点击事件

protected:
	QPixmap m_pic;//与扑克牌对应的图片
	QPixmap m_back;//扑克背面图
	GameUser* m_owner;//玩家
	Card m_card;//
	bool m_selected;

	bool m_frontSide;


};

#endif // CARDPIC_H
