#include "Card.h"
MapItem::MapItem() :
    QObject(),
    QGraphicsPixmapItem(),
    mBoundingRect(QRect()),
    mShape(QPainterPath()),
    mImageSelected(0),
    mImageEvent(0),
    mMapItemName(""),
    mObstacle(false)
{

}

MapItem::~MapItem()
{

}

QPixmap MapItem::getImage()
{
    return mImage.copy(static_cast<int>(mImageSelected * boundingRect().width()), 0, static_cast<int>(boundingRect().width()), static_cast<int>(boundingRect().height()));
}


QString MapItem::invocName()
{
    return mMapItemName;
}

QRectF MapItem::boundingRect() const
{
    return mBoundingRect;
}

QPainterPath MapItem::shape() const
{
    return mShape;
}

void MapItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    painter->setRenderHint(QPainter::Antialiasing);
    painter->drawPixmap(0, 0, mImage, static_cast<int>(mImageSelected * boundingRect().width()), static_cast<int>(mImageEvent * boundingRect().height()), static_cast<int>(boundingRect().width()), static_cast<int>(boundingRect().height()));
    Q_UNUSED(widget)
        Q_UNUSED(option)
}




Card::Card(unsigned int point, unsigned int color):
    mPoint(point),
    mColor(color),
    MapItem()
{
    initMapItem();
}

void Card::initMapItem()
{
    QString buff = "";
    mMapItemName = "�˿�";
    mImageSelected = 0;
    //mImage = QPixmap(":/tarneeb_client/res/card.png");
    m_cardSize = QSize(80,105);

    QPixmap cardsPic(":/tarneeb_client/res/card.png");
    if(mPoint==2)
    mImage=cardsPic.copy((14-mPoint)* m_cardSize.width(),(mColor-1)* m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    else
    {
        mImage = cardsPic.copy((mPoint-3) * m_cardSize.width(), (mColor - 1) * m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    }

    if(mPoint==0||mColor==0)mImage = cardsPic.copy(2 * m_cardSize.width(),4 * m_cardSize.height(), m_cardSize.width(), m_cardSize.height());
    setZValue(0);
    
    mBoundingRect = QRect(0, 0, mImage.width(), mImage.height());

    //setRotation(rand() % (30) - 15);
}

bool Card::isObstacle()
{
    return mObstacle;
}

Card::~Card()
{

}
