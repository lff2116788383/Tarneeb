#include "GamePanel.h"


GamePanel::GamePanel(QWidget *parent)
	: QFrame(parent)
{
	//ui.setupUi(this);
	m_cardSize = QSize(80, 105);
	InitCardPicMap();


	m_baseCard = new CardPic(this);
	m_movingCard = new CardPic(this);
	//m_baseCard->SetPic(m_cardBackPic, m_cardBackPic);
	m_movingCard->SetPic(m_cardBackPic, m_cardBackPic);



	QString styleSheet;
	styleSheet =
		"QPushButton			{ border-image: url(:/tarneeb_client/res/button.png) 0 267 0 0; color: white; }"
		"QPushButton:hover		{ border-image: url(:/tarneeb_client/res/button.png) 0 178 0 89; }"
		"QPushButton:pressed	{ border-image: url(:/tarneeb_client/res/button.png) 0 89 0 178; }";



	m_shuffleButton = new QPushButton(this);
	m_shuffleButton->setGeometry(this->width() / 2 - 90 / 2, this->height() / 2 - 105 / 2 + 105 + 20, 90, 32);
	m_shuffleButton->setFocusPolicy(Qt::NoFocus);
	m_shuffleButton->setText(tr("Poker Shuffle"));
	m_shuffleButton->show();
	m_shuffleButton->setFixedSize(90, 32);
	m_shuffleButton->setStyleSheet(styleSheet);
	connect(m_shuffleButton, SIGNAL(clicked()), this, SLOT(OnShuffleBtnClicked()));
}

GamePanel::~GamePanel()
{
}

void GamePanel::OnShuffleBtnClicked()
{
	m_baseCardPos = QPoint((width() - m_cardSize.width()) / 2, height() / 2 - 100);
	//m_baseCard->move(m_baseCardPos);
	//m_movingCard->move(m_baseCardPos);

	QPropertyAnimation* animation = new QPropertyAnimation(m_movingCard, "geometry");

	animation->setDuration(500);

	animation->setStartValue(QRect(0, 0, 80,105 ));

	animation->setEndValue(QRect(250, 250, 80, 105));


	animation->start();
	
}

void GamePanel::paintEvent(QPaintEvent* event)
{
	static QPixmap bk(":/tarneeb_client/res/table.png");
	QPainter painter(this);
	painter.drawPixmap(rect(), bk);
}

void GamePanel::resizeEvent(QResizeEvent* event)
{
}

void GamePanel::InitCardPicMap()
{
	QPixmap cardsPic(":/tarneeb_client/res/card.png");

	m_cardBackPic = cardsPic.copy(2 * m_cardSize.width(), 4 * m_cardSize.height(),
		m_cardSize.width(), m_cardSize.height());

	int i = 0, j = 0;
	for (unsigned short suit = Diamond, i = 0; suit <= Spade; suit++, i++)//��ɫ �ӷ��鵽���ҵ���
	{
		for (unsigned short pt = Card_2, j = 0; pt <= Card_A; pt++, j++)//���� ��2��A����
		{
			Card card = { pt ,suit };
			/*card.point = (CardPoint)pt;
			card.color = (CardSuit)suit;*/
			if (pt == 2)
			{
				j = 12;
			}
			if (pt == 3)
			{
				j = 0;
			}

			CutCardPic(cardsPic, j * m_cardSize.width(), i * m_cardSize.height(), card);
		}
	}

	// ��С�������⣬�ֱ���
	/*Card card;

	card.point = Card_SJ;
	card.suit = Suit_Begin;
	CutCardPic(cardsPic, 0, 4 * m_cardSize.height(), card);

	card.point = Card_BJ;
	card.suit = Suit_Begin;
	CutCardPic(cardsPic, m_cardSize.width(), 4 * m_cardSize.height(), card);*/
}

void GamePanel::CutCardPic(const QPixmap& cardsPic, int x, int y, Card card)
{
	QPixmap pic = cardsPic.copy(x, y, m_cardSize.width(), m_cardSize.height());

	CardPic* cardPic = new CardPic(this);
	cardPic->hide();
	cardPic->SetPic(pic, m_cardBackPic);

	cardPic->SetCard(card);
	m_cardPicMap.insert(card, cardPic);

	connect(cardPic, SIGNAL(NotifySelected(Qt::MouseButton)), this, SLOT(OnCardPicSelected(Qt::MouseButton)));
}


void GamePanel::OnCardPicSelected(Qt::MouseButton mouseButton)
{
}