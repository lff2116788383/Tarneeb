#include "Tarneeb.h"

Tarneeb::Tarneeb(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	setFixedSize(1000, 650);
	setWindowTitle(tr("Lord Card Game"));
	//// ����һ�� item
	//QGraphicsSimpleTextItem* pItem = new QGraphicsSimpleTextItem();
	//pItem->setText(QString::fromLocal8Bit("һȥؼ������"));

	//// ����
	//QFont font = pItem->font();
	//font.setPixelSize(20);  // ���ش�С
	//font.setItalic(true);  // б��
	//font.setUnderline(true);  // �»���
	//pItem->setFont(font);

	//pItem->setBrush(QBrush(QColor(0, 160, 230)));

	//// �� item ������������
	//QGraphicsScene* pScene = new QGraphicsScene();
	//pScene->addItem(pItem);

	
	
	// Ϊ��ͼ���ó���
	 pView = new QGraphicsView(this);
	 pView->setGeometry(0,0,this->width(),this->height());

	 table = new GameTable(pView);

	pView->setScene(table->GetScene());
	pView->setStyleSheet("border:none; background:transparent;");

	
	pView->show();
	
	

	

}

Tarneeb::~Tarneeb()
{
}

void Tarneeb::paintEvent(QPaintEvent*)
{
	static QPixmap bk(":/tarneeb_client/res/table.png");
	QPainter painter(this);
	painter.drawPixmap(rect(), bk);
}