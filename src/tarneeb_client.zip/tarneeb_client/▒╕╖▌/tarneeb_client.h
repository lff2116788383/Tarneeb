#pragma once

#include <QtWidgets/QWidget>
#include "ui_tarneeb_client.h"
#include <QPainter>
#include "Cards.h"
#include <QVector>
#include <algorithm>
#include <QPushButton>
#include "GameTable.h"
#include "CardPic.h"
#include <QPropertyAnimation>
class tarneeb_client : public QWidget
{
    Q_OBJECT

public:
    tarneeb_client(QWidget *parent = Q_NULLPTR);

    void paintEvent(QPaintEvent* event);

    void InitCardPicMap();
    void CutCardPic(const QPixmap& cardsPic, int x, int y, Card card);	// �ڿ�Ƭͼ���Ͻ�Ϊ(x, y)������ָ���ߴ磬��card��Ӧ����
    void SortCard(QVector<Card>& handcards, unsigned short color);
protected slots:
    // �û���ť����Ӧ
    void OnShuffleBtnClicked();
    void OnCardPicSelected(Qt::MouseButton mouseButton);

private:
    GameTable* table;
    GameUser user[4];

    bool isStart=false;
    const int cardSpacing = 20;		// �Ƽ��
    int x;
    int y;
    QPixmap pix;

    // ���ƶ���ʱ���ƺ��ƶ���ͼƬ
    CardPic* m_baseCard;
    CardPic* m_movingCard;

    QPoint m_baseCardPos;

    QVector<Card>totalcards;
   QVector<Card>player[4];

    QSize m_cardSize;
    QMap<Card, CardPic*> m_cardPicMap;	// ÿ�ſ�Ƭ��Ӧһ��ͼƬ

    QPixmap m_cardBackPic;//�����˿�ͼƬ  

    QPushButton* m_shuffleButton;//ϴ�ư�ť

private:
    Ui::tarneeb_clientClass ui;


};
