#include "Poker.h"

Poker::Poker()
{
	//Card	card(0, 0);
	//Card* card;
	for (int i = 1; i <= 4; i++)
	{
		for (int j = 2; j <= 14; j++)
		{
			
			//if (j == 0)j = 1;
			Card* card=new Card(j,i);
			//Card	card(i, j);
			mCards.push_back(card);
			//delete card;
		}
	}

	Shuffle();
}

Poker::~Poker()
{
	
}

void Poker::Shuffle()
{
	//����˳��
	//std::random_shuffle(mCards.begin(), mCards.end());
}

QVector<Card*> Poker::GetCards()
{
	return mCards;
	
}
