#pragma once
#include "GameUser.h"
class CGameSeat
{
	GameUser* m_pUser;
	//int m_nAllin ;
	int m_nSeatID;
	bool m_bPlaying;//�Ƿ�������

	int seatState;

	int64_t addonChips;
	int64_t rebuyChips;
	int64_t rebuyBounty;
	int64_t addonBounty;
	int m_BestCard[5];//�����
public:
};